=== Slide IMG ===
Contributors: ihoan caodem.com
Donate link: https://paypal.me/ihoan
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html
Tags: Slide IMG, Slideshow, ihoan, caodem
Tested up to: 5.6
Requires PHP: 5.6.3

Create photo slideshows for the website.

== Description ==

Create photo slideshows for the website.

== Installation ==

=== From within WordPress ===

1. Visit 'Plugins > Add New'
2. Search for 'Slide IMG'
3. Activate Slide IMG from your Plugins page.

=== Manually ===

1. Upload the `Slide-IMG` folder to the `/wp-content/plugins/` directory
2. Activate the Slide IMG plugin through the 'Plugins' menu in WordPress
3. Go to "after activation" below.

== Frequently Asked Questions ==

You'll find answers to many of your questions on (https://caodem.com/hoi-dap).

== Screenshots ==

== Changelog ==

= 1.0 =
* First release.

<?php
// dua muc luc vao content
function Mucluc_tobot_add_content($content) {
if(is_singular('post')) {
ob_start();
?>
<div class="mucluc-content">
<button id="nuttocbot" onclick="tocbothoan()">MENU</button>
<aside id="tocbottren" class="toc"></aside>
</div>
<!-- menu toc danh muc o bai viet -->
<button id="menutoc" style="display:none"><img title="" style="margin:0px;padding:0px;border:0px;display:initial;max-width:30px;" src="<?php echo plugins_url('img/mucluc_list.png', __FILE__); ?>" width="30px" /></button>
<div id="hientoc" class="toccao">
	<div class="toccao-content">
		<span class="menuclose">&times;</span>
		<p><aside class="tocbot"></aside></p>
	</div>
 </div>
<?php
$mucluc_showmenu = ob_get_clean();
return $mucluc_showmenu . "<div class='noidungtoc'>" . $content . "</div>";
}else {
return $content;
}
}
add_filter('the_content', 'Mucluc_tobot_add_content');

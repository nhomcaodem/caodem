// menu tocbot hien thi tren cung
tocbot.init({
        tocSelector: '.toc',
        contentSelector: '.noidungtoc',
		headingSelector: 'h1, h2, h3, h4',
        hasInnerContainers: true,
		collapseDepth  :  6,
        headingsOffset :  1,
        orderedList    :  true
    });
	function tocbothoan() {
  var x = document.getElementsByClassName("toc")[0];
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
// hien thi nut tocbot khi keo xuong duoi
tocbot.init({
        tocSelector: '.tocbot',
        contentSelector: '.noidungtoc',
		headingSelector: 'h1, h2, h3, h4',
        hasInnerContainers: true,
		collapseDepth  :  6,
        headingsOffset :  1,
        orderedList    :  true
    });
var cao = document.getElementById("hientoc");
var btn = document.getElementById("menutoc");
var span = document.getElementsByClassName("menuclose")[0];
btn.onclick = function() {
  cao.style.display = "block";
}

span.onclick = function() {
  cao.style.display = "none";
}
window.onclick = function(event) {
  if (event.target == cao) {
    cao.style.display = "none";
  }
}
// keo chuot moi hien thị tocbot
var mybutton = document.getElementById("menutoc");
window.onscroll = function() {scrollFunction()};
function scrollFunction() {
  if (document.body.scrollTop > 700 || document.documentElement.scrollTop > 700) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}
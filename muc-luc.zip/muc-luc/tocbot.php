<?php
/**
* Plugin name: Muc luc
* Plugin URL: https://www.caodem.com
* Description: Create a content table of contents for articles
* Version: 1.0.0
* Author: ihoan caodem.com
* Author URL: https://www.caodem.com
* License: GPLv2 or later
/**
* Create content table for articles, designed by ihoan from caodem.com. The plugin is completely free, with the desire to serve the Wordpress writing community.
*/
// add hook js css muc luc
function add_tocbot_mucluc_head_caodem() {
wp_enqueue_script( 'mucluctocbot-js', plugins_url( 'menutoc/tocbot.min.js', __FILE__ ), array(), '1.0.0');
wp_enqueue_style( 'mucluctocbot-css', plugins_url( 'menutoc/tocbot.css', __FILE__ ), array(), '1.0.0');
wp_enqueue_script( 'footertocbot-js', plugins_url( 'menutoc/tocbot.js', __FILE__ ), array(), '1.0.0' , true);
}
add_action( 'wp_enqueue_scripts', 'add_tocbot_mucluc_head_caodem' );
// them id cho the h1 h2 h3 h4
function auto_id_headings_tocbot_caodem( $content ) {
	$content = preg_replace_callback( '/(\<h[1-6](.*?))\>(.*)(<\/h[1-6]>)/i', function( $matches ) {
		if ( ! stripos( $matches[0], 'id=' ) ) :
			$matches[0] = $matches[1] . $matches[2] . ' id="' . sanitize_title( $matches[3] ) . '">' . $matches[3] . $matches[4];
		endif;
		return $matches[0];
	}, $content );
    return $content;
}
add_filter( 'the_content', 'auto_id_headings_tocbot_caodem' );
// dua muc luc vao content
include( plugin_dir_path( __FILE__ ) . 'inc/mucluc.php');
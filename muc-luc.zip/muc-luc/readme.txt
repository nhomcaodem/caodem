=== Muc luc ===
Contributors: ihoan caodem.com
Donate link: https://caodem.com
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html
Tags: muc luc, table of contents
Tested up to: 5.5
Requires PHP: 5.6.3

Create content table for articles.

== Description ==

Create content table for articles.

== Installation ==

=== From within WordPress ===

1. Visit 'Plugins > Add New'
2. Search for 'Trusted Order Notifications'
3. Activate Trusted Order Notifications from your Plugins page.

=== Manually ===

1. Upload the `trusted-order-notifications` folder to the `/wp-content/plugins/` directory
2. Activate the Trusted Order Notifications plugin through the 'Plugins' menu in WordPress
3. Go to "after activation" below.

== Frequently Asked Questions ==

You'll find answers to many of your questions on (https://caodem.com).

== Screenshots ==

== Changelog ==

= 1.0.0 =
* First release.
<?php
/**
* Plugin name: Dat Pass
* Plugin URL: https://www.caodem.com
* Description: Content is locked
* Domain Path: /languages
* Version: 1.1.3
* Author: ihoan caodem.com
* Author URL: https://www.caodem.com
* License: GPLv3 or later
/**
* Content is locked.
*/
// add css dat pass
function Dat_pass_addjscss_head() {
wp_enqueue_style( 'datpass-css', plugins_url( 'css/datpass-style.css', __FILE__ ), array(), '1.1');
}
add_action( 'wp_enqueue_scripts', 'Dat_pass_addjscss_head' );
// add global
$datpass_options = get_option('datpass_settings');
// trinh quan ly admin va content
include( plugin_dir_path( __FILE__ ) . 'inc/datpass-admin.php');
include( plugin_dir_path( __FILE__ ) . 'inc/datpass-content.php');
// the ngon ngu
function Dat_pass_load_textdomain() {
  load_plugin_textdomain( 'dat-pass', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' ); 
}
add_action( 'plugins_loaded', 'Dat_pass_load_textdomain' );

=== Dat Pass ===
Contributors: ihoan caodem.com
Donate link: https://paypal.me/ihoan
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html
Tags: Content is locked, Add password content
Tested up to: 5.6
Requires PHP: 5.6.3

Content is locked.

== Description ==

Content is locked.

== Installation ==

=== From within WordPress ===

1. Visit 'Plugins > Add New'
2. Search for 'Dat Pass'
3. Activate Dat Pass from your Plugins page.

=== Manually ===

1. Upload the `Dat-pass` folder to the `/wp-content/plugins/` directory
2. Activate the Dat Pass plugin through the 'Plugins' menu in WordPress
3. Go to "after activation" below.

== Frequently Asked Questions ==

You'll find answers to many of your questions on (https://caodem.com/hoi-dap).

== Screenshots ==

== Changelog ==

= 1.1 =
* Add style color.

= 1.0 =
* First release.

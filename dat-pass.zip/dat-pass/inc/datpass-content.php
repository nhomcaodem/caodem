<?php
// them shortcode pass content
function Dat_pass_shortcode($atts, $content = null) {
	global $datpass_options;
	extract(shortcode_atts(array('pass' => ''), $atts));
	$dat_error 	= __('Sorry! The password you entered is incorrect ...','dat-pass');
	ob_start(); ?>
	<div class="datbox <?php echo $datpass_options['theme']; ?>">
	<div class="dathinh"><img src="<?php echo plugins_url('../img/datpass.png', __FILE__); ?>" /></div>
	<div class="datform">
	<div class="dattitle"><?php _e('Content is locked','dat-pass'); ?>
	<div class="datghic"><?php _e('You need to enter a password to unlock this content','dat-pass'); ?></div>
	</div>
	<form action="#" method="post" class="datpass" id="datpass">
	<div class="datinput">
    <input class="datnhap <?php echo $datpass_options['theme']; ?>" type="password" size="20" placeholder="<?php _e('PASSWORD','dat-pass'); ?>" name="dat_input">
    <input class="datnut" type="submit" name="dat_submit" value="<?php _e('VIEW NOW','dat-pass'); ?>">
	</div>
	<?php $form = ob_get_clean();
	if (isset($_POST['dat_submit'])) {
		if ($_POST['dat_input'] == $pass AND $pass != '') {
			return $content;
		}
		else
		{
			return $form.'<div class="datloi">'.$dat_error.'</form><div></div></div></div></div>';
		}
	}
	else
	{
		return $form .'</form><div></div></div></div>';
	}
}
add_shortcode('datpass', 'Dat_pass_shortcode');

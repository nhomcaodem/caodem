<?php
// code add header and footer setting admin
function datpass_options_page() {
	global $datpass_options;
	ob_start(); ?>
	<div class="wrap" style="font-size:16px;">
		<h2 style="background:#593b79;padding:20px;color:#fff;border-radius:7px;"><b><?php echo __('DAT PASS SETTINGS', 'dat-pass'); ?></b></h2>
		<form method="post" action="options.php">
			<?php settings_fields('datpass_settings_group'); ?>
		   <h4 style="font-size:26px;color:#593b79"><?php _e('Change the options below', 'dat-pass'); ?></h4>
			<div style="margin-top:20px;background:#fff;padding:30px;box-shadow:0px 0px 10px #777;border-radius:10px;">
		       <div style="margin-bottom:20px;"><b style="font-size:24px;color:#593b79"><?php _e('Color options', 'dat-pass'); ?></b></div>
		       <?php $styles = array('White', 'Dark', 'Dark2', 'Purple', 'Pro', 'Pro2', 'Pro3', 'Pro4', 'Pro5', 'Pro6', 'Pro7', 'Fox'); ?>
               <select style="font-size:19px;width:200px;border:4px solid #593b79;border-radius:10px;" name="datpass_settings[theme]" id="datpass_settings[theme]" > 
               <?php foreach($styles as $style) { ?> 
               <?php if($datpass_options['theme'] == $style) { $selected = 'selected="selected"'; } else { $selected = ''; } ?>
               <option value="<?php echo $style; ?>" <?php echo $selected; ?>><?php echo $style; ?></option> 
               <?php } ?> 
               </select>
		   </div>
		   <div class="submit"><input style="background:#593b79;color:#fff;padding: 2px 16px 2px 16px;border:none;font-size:24px;border-radius:10px;" type="submit" class="button-primary" value="<?php _e('Save settings', 'dat-pass'); ?>" /></div>
		</form>
	<div style="background:#593b79;padding:20px;color:#fff;opacity:0.5;border-radius:10px;"><?php _e('Thank you for using the Dat Pass plugin', 'dat-pass'); ?> <b><a style="color:#999" href="https://caodem.com">CAO DEM</a></b></div>
	</div>
	<?php
	echo ob_get_clean();
}
// add muc luc menu admin
function datpass_add_options_link() {
	add_options_page('Dat Pass', 'Dat Pass', 'manage_options', 'datpass-options', 'datpass_options_page');
}
add_action('admin_menu', 'datpass_add_options_link');
// add thong tin vao database
function datpass_register_settings() {
	register_setting('datpass_settings_group', 'datpass_settings');
}
add_action('admin_init', 'datpass_register_settings');